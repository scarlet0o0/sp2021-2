#define PORTNUM 10003
#define SERVERIPADDR "127.0.0.1"
#define BUFLEN 256
#define TRUE 1
#define FALSE 0
#define QUITMSG "QUIT"
#define LISTENLEN 5
