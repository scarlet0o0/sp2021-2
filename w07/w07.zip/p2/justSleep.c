#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
int main(){
	printf("5초 sleep\n");

	sleep(5);

	return 0;
}
